// File: admin/src/assets/assets.js

export const assets = {
    // Logo admin
    logo: "https://via.placeholder.com/200x50?text=Admin+Logo",
    
    // Các icon chức năng
    add_icon: "https://via.placeholder.com/50?text=Add",
    order_icon: "https://via.placeholder.com/50?text=List",
    upload_area: "https://via.placeholder.com/150?text=Upload+Image",
    list_icon: "https://via.placeholder.com/50?text=List",
    people_icon: "https://via.placeholder.com/50?text=People",
    doctor_icon: "https://via.placeholder.com/50?text=Doctor",
    appointment_icon: "https://via.placeholder.com/50?text=Appt",
    cancel_icon: "https://via.placeholder.com/50?text=Cancel",
}