import React from "react";

const AllApointments = () => {
  return (
    <div>
      <div>
        <p>All Apointment</p>
      </div>
    </div>
  );
};

export default AllApointments;
