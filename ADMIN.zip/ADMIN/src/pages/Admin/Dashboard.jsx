import React from "react";

const Dashboard = () => {
  return (
    <div>
      <h1>Admin Dashboard</h1>
      <p>
        Welcome to the admin dashboard. Here you can manage your application
        settings and users.
      </p>
    </div>
  );
};

export default Dashboard;
