import React from "react";

const DoctorList = () => {
  return <div></div>;
};

export default DoctorList;
