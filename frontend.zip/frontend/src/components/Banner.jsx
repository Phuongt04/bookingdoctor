import React from "react";
import { assets } from "../assets/assets_frontend/assets";
import { useNavigate } from "react-router-dom";

const Banner = () => {
  const navigate = useNavigate();
  return (
    <div className="flex bg-[#5f6fff] rounded-lg px-6 sm:px-10 md:px-14 lg:px-12 my-20 md:my-10 ">
      {/* left side */}
      <div className="flex-1 py-8 sm:py-10 md:py-16 lg:py-24 lg:pl-5 ">
        <div className="text-xl sm:text-2xl md:text-3xl lg:text-5xl font-semibold text-white ">
          <p>Đặt lịch khám bệnh</p>
          <p className="mt-4">Với các bác sỹ uy tín</p>
        </div>
        <button
          onClick={() => {
            navigate("/login");
            scrollTo(0, 0);
          }}
          className="bg-white text-sm sm:text-base text-gray-600 mt-5 px-8 py-3 rounded-full hover:scale-105 transition-all"
        >
          TẠO TÀI KHOAN NGAY
        </button>
      </div>

      {/* right side */}
      <div className=" hidden md:block md:w-1/2 lg:w-[370px] relative">
        {/* logo */}
        <img
          className=" w-full absolute bottom-0 right-40
           h-auto max-w-md "
          src={assets.appointment_img}
          alt=""
        />
      </div>
    </div>
  );
};

export default Banner;
